#include <iostream>
#include "GroceryInventory.h"
using namespace std;

void GroceryInventory::SetFrequency(int count) {
	
}

void GroceryInventory::PrintMenu() {       /* Outputs the menu using one line instead of overcrowding the main file */
	cout << endl << "Please make a selection from the following menu (1, 2, 3, or 4)" << endl;
	cout << endl << "1. Search for an item" << endl;
	cout << "2. Print a list of items purchased and their frequency" << endl;
	cout << "3. Print a histogram of items purchased and their frequency" << endl;
	cout << "4. Exit the program" << endl;
}
