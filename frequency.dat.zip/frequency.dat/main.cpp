#include <iostream>
#include <fstream>
#include <vector>
#include <map>
#include <string>
#include "GroceryInventory.h"
using namespace std;

int main() {
	std::string menuSelection = "0";
	string word;
	ifstream inFS("CS210_Project_Three_Input_File.txt"); /* Opens text file */
	vector <string> items;
	map<string, int> wordCounts;

	std::cout << "Welcome to Corner Grocer" << std::endl;

	/* This loop repeats until the user inputs 4. This exits the program */
	while (menuSelection != "4") {
		GroceryInventory::PrintMenu(); /* The menu options were defined in a separate file to avoid overcrowding */
		cin >> menuSelection;

		if (menuSelection == "1") {
			int count = 0;
			string searchItem;

			while (inFS >> word) {
				items.push_back(word);       /* Passes through the text file reading every word */
			}

			std::cout << "What item are you searching for? (Capitalize and use correct spelling)" << endl; /* User inputs the item they are searching for */
			cin >> searchItem;

			for (const string& item : items) { /* This other loop counts how many times user's input is found in the txt file */
				if (item == searchItem) {
					++count;
				}
			}
			std::cout << count << endl; /* Outputs just word count number */
		}

		else if (menuSelection == "2") {
			inFS.clear();
			inFS. seekg(0, ios::beg);       /* Restarts the file */

			map<string, int> count;
			while (inFS >> word) {
				++ count[word];       /* Passes through the text file counting and adding every new/repeating words */
			}
			for (const auto& pair : count) {
				std::cout << pair.first << " " << pair.second << std::endl;
			}
		}

		else if (menuSelection == "3") {
			inFS.clear();
			inFS.seekg(0, ios::beg);       /* Restarts the file */

			map<string, int> count;
			while (inFS >> word) {
				++count[word];       /* Passes through the text file counting and adding every new/repeating words */
			}
			for (const auto& pair : count) {
				std::cout << pair.first << " " << string(pair.second, '*') << std::endl;
			}
		}

		else if (menuSelection == "4") {       /* If user inputs 4, exit program, the loop and program exits */
			break;
		}

		else {       /* Avoids user inputting anything other than the 4 menu options */
			std::cout << "ERROR the selection you entered is unavailable, please try again" << endl;
		}
	}

	inFS.close();       /*Close txt file*/
	std::cout << "Have a nice day!";
	
}