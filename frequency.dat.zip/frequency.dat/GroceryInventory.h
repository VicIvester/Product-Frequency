#ifndef GROCERY_INVENTORY_H
#define GROCERY_INVENTORY_H
#include <string>
using namespace std;

class GroceryInventory {
public:
	void SetFrequency(int count);
	static void PrintMenu();

private:
	string itemName;
	int count = 0;

};
#endif

